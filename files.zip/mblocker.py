import keyboard as k
from tkinter import messagebox

while True:
    k.wait("m")
    k.press_and_release("backspace")
    messagebox.showinfo(title="Sorry",message="Button M is not avaible.")